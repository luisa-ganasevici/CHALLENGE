# -- coding: utf-8 --
from datetime import datetime

agendamentos = []

def exibir_menu():
    print("\n=== MENU HC-USP ===")
    print("1. Novo agendamento")
    print("2. Cancelar agendamento")
    print("3. Consultar agendamentos")
    print("4. Sair")

def validar_cpf(cpf):
    if len(cpf) != 11 or not cpf.isdigit():
        raise ValueError("CPF deve conter 11 dígitos numéricos")

def validar_data(data):
    try:
        datetime.strptime(data, '%d/%m/%Y')
    except ValueError:
        raise ValueError("Formato de data inválido (DD/MM/AAAA)")

def validar_hora(hora):
    try:
        datetime.strptime(hora, '%H:%M')
    except ValueError:
        raise ValueError("Formato de hora inválido (HH:MM)")

def novo_agendamento():
    while True:
        try:
            cpf = input("CPF do paciente: ").strip()
            validar_cpf(cpf)
            
            data = input("Data do atendimento (DD/MM/AAAA): ").strip()
            validar_data(data)
            
            hora = input("Hora do atendimento (HH:MM): ").strip()
            validar_hora(hora)
            
            for ag in agendamentos:
                if ag['data'] == data and ag['hora'] == hora:
                    raise ValueError("Horário já ocupado")
            
            agendamentos.append({
                'cpf': cpf,
                'data': data,
                'hora': hora,
                'confirmado': False
            })
            print("Agendamento realizado com sucesso!")
            return
            
        except ValueError as e:
            print(f"Erro: {e}\nTente novamente.")

def cancelar_agendamento():
    cpf = input("CPF do paciente: ").strip()
    agendamentos_paciente = [ag for ag in agendamentos if ag['cpf'] == cpf]
    
    if not agendamentos_paciente:
        print("Nenhum agendamento encontrado.")
        return
    
    print("\nAgendamentos encontrados:")
    for i, ag in enumerate(agendamentos_paciente, 1):
        print(f"{i}. {ag['data']} às {ag['hora']}")
    
    try:
        escolha = int(input("Escolha o agendamento para cancelar: ")) - 1
        if 0 <= escolha < len(agendamentos_paciente):
            agendamentos.remove(agendamentos_paciente[escolha])
            print("Agendamento cancelado com sucesso!")
        else:
            print("Opção inválida.")
    except ValueError:
        print("Entrada inválida.")

def consultar_agendamentos():
    if not agendamentos:
        print("Nenhum agendamento registrado.")
        return
    
    print("\n=== AGENDAMENTOS ATIVOS ===")
    for i, ag in enumerate(agendamentos, 1):
        status = "Confirmado" if ag['confirmado'] else "Pendente"
        print(f"{i}. CPF: {ag['cpf']} | {ag['data']} às {ag['hora']} | Status: {status}")

def main():
    while True:
        exibir_menu()
        opcao = input("Escolha uma opção: ").strip()
        
        if opcao == '1':
            novo_agendamento()
        elif opcao == '2':
            cancelar_agendamento()
        elif opcao == '3':
            consultar_agendamentos()
        elif opcao == '4':
            print("Encerrando sistema...")
            break
        else:
            print("Opção inválida. Tente novamente.")

if _name_ == "_main_":
    main()