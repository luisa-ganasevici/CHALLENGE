
  const navToggle = document.querySelector('.nav-toggle');
  const navUl = document.querySelector('.main-nav ul');
  navToggle.addEventListener('click', () => {
    navUl.classList.toggle('open');
  });

  document.querySelectorAll('.pergunta h3').forEach(pergunta => {
    pergunta.addEventListener('click', () => {
      const resposta = pergunta.nextElementSibling;
      const seta = pergunta.querySelector('.seta');
      
      resposta.classList.toggle('mostrar');
      seta.textContent = resposta.classList.contains('mostrar') ? '▲' : '▼';
    });
  });

  document.querySelectorAll('.pergunta h3').forEach(pergunta => {
    pergunta.addEventListener('click', () => {
      const resposta = pergunta.nextElementSibling;
      const seta = pergunta.querySelector('.seta');
      
      resposta.classList.toggle('mostrar');
      seta.textContent = resposta.classList.contains('mostrar') ? '▲' : '▼';
    });
  });

  document.addEventListener('DOMContentLoaded', function() {
    const navUl = document.querySelector('.main-nav ul');
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelectorAll('.main-nav a');

    document.addEventListener('click', function(e) {
      if (
        navUl && navUl.classList.contains('open') &&
        !e.target.closest('.main-nav')
      ) {
        navUl.classList.remove('open');
      }
    });

    if (navLinks && navUl) {
      navLinks.forEach(link => {
        link.addEventListener('click', () => {
          navUl.classList.remove('open');
        });
      });
    }
  });
