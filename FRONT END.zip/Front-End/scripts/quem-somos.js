
    document.addEventListener('DOMContentLoaded', function() {
      const navToggle = document.querySelector('.nav-toggle');
      const navUl = document.querySelector('.main-nav ul');
      if (navToggle && navUl) {
        navToggle.addEventListener('click', () => {
          navUl.classList.toggle('open');
        });
      }
      document.querySelectorAll('.main-nav a').forEach(link => {
        link.addEventListener('click', () => {
          if (navUl) navUl.classList.remove('open');
        });
      });
      document.addEventListener('click', function(e) {
        if (
          navUl && navUl.classList.contains('open') &&
          !e.target.closest('.main-nav')
        ) {
          navUl.classList.remove('open');
        }
      });
    });
