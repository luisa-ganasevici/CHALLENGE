
    document.addEventListener('DOMContentLoaded', function() {
      const navToggle = document.querySelector('.nav-toggle');
      const navUl = document.querySelector('.main-nav ul');
      if (navToggle && navUl) {
        navToggle.addEventListener('click', () => {
          navUl.classList.toggle('open');
        });
      }
      document.querySelectorAll('.main-nav a').forEach(link => {
        link.addEventListener('click', () => {
          if (navUl) navUl.classList.remove('open');
        });
      });
      document.addEventListener('click', function(e) {
        if (
          navUl && navUl.classList.contains('open') &&
          !e.target.closest('.main-nav')
        ) {
          navUl.classList.remove('open');
        }
      });
    });



    const form = document.getElementById('formAgendamento');
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      limparErros();

      const nome = document.getElementById('nome').value.trim();
      const email = document.getElementById('email').value.trim();
      const data = document.getElementById('data').value;

      let valido = true;

      if (nome === '') {
        exibirErro('erroNome', 'Por favor, preencha seu nome.');
        valido = false;
      }

      if (email === '' || !validarEmail(email)) {
        exibirErro('erroEmail', 'Insira um e-mail válido.');
        valido = false;
      }

      if (data === '') {
        exibirErro('erroData', 'Selecione uma data.');
        valido = false;
      }

      if (valido) {
        document.getElementById('mensagem-sucesso').textContent = 'Agendamento realizado com sucesso!';
        form.reset();
        setTimeout(() => {
          document.getElementById('mensagem-sucesso').textContent = '';
        }, 4000);
      }
    });

    function validarEmail(email) {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    function exibirErro(elementoId, mensagem) {
      const erro = document.getElementById(elementoId);
      erro.textContent = mensagem;
    }

    function limparErros() {
      document.querySelectorAll('.erro').forEach(erro => {
        erro.textContent = '';
      });
    }
