package br.com.clinica.servico;
import br.com.clinica.hc.Paciente;


public class ServicoPaciente {
    private boolean convenio;

    public ServicoPaciente(boolean convenio) {
        this.convenio = convenio;
    }

    public boolean isConvenio() {
        return convenio;
    }

    public void setConvenio(boolean convenio) {
        this.convenio = convenio;
    }
}
